# GramKart Progressive Web App (PWA) — Deployment Bundle

This `pwa/` directory (and the root-level `gramkart-pwa-deploy.zip` archive) contains the complete, production-ready HTTPS Progressive Web App bundle for **GramKart**. All Customer App and Admin Panel data (`products`, `cart`, `orders`, `profile`, `language`, and `adminAuth`) is persisted locally in `localStorage`.

## Root Deployment Files
- `index.html` — Mobile-first viewport, `#15803D` theme color, splash screen, manifest link, and app shell
- `manifest.json` — `"name": "GramKart"`, `"start_url": "/"`, `"scope": "/"`, `"display": "standalone"`, `192x192` and `512x512` `any` + `maskable` icons
- `service-worker.js` — Offline caching for app shell, icons, and bundled artwork
- `app.js` & `styles.css` — Interactive Customer App & Admin Panel (`admin@gramkart.demo` / `Admin123`)
- `icons/` — `icon-192.png`, `icon-192-maskable.png`, `icon-512.png`, `icon-512-maskable.png`
- `assets/` — `hero.jpg`, `empty-cart.jpg`, `order-success.jpg`
- `_headers` & `_redirects` — Netlify Drop cache headers, manifest MIME type, and SPA fallback

## Deploy on Netlify Drop (HTTPS)
1. Download **`gramkart-pwa-deploy.zip`** from the project root (or extract it to a folder).
2. Open **`https://app.netlify.com/drop`**.
3. Drag and drop **`gramkart-pwa-deploy.zip`** (or the extracted folder containing `index.html` at the root) onto the drop zone.
4. Netlify immediately hosts GramKart at an **`https://...netlify.app`** root URL.

## Install on Android Phones
1. Open the deployed `https://` Netlify URL in **Google Chrome** on your Android phone.
2. Tap **Install App** on the green banner inside GramKart (or tap **⋮ menu → Install app / Add to Home screen**).
3. Confirm **Install** — GramKart installs with its custom icon, launches in **standalone** mode with its splash screen, and works offline.
